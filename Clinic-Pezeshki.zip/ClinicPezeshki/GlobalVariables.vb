﻿Module GlobalVariables
    Public LoggedInUsername As String
    Public LoggedInUserID As Integer
    Public LoggedInRole As String
    Public LoggedInUserFullName As String
    Public connectionString As String = "Server=localhost\SQLEXPRESS;Database=ClinicPezeshki;Integrated Security=True;"
End Module
